.onAttach <- function(libname, pkgname) {
  packageStartupMessage("PACKAGE: fhidataold")
  packageStartupMessage("Version: 2020.10.02 at 09:20")
  packageStartupMessage("Developed by Richard White, Norwegian Institute of Public Health")
}
