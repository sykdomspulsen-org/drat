library(testthat)
library(fhidataold)

test_check("fhidataold")
