.onAttach <- function(libname, pkgname) {
  packageStartupMessage("PACKAGE: drathelper")
  packageStartupMessage("Version 2020.09.02 at 03:51")
  packageStartupMessage("Developed by Richard White, Norwegian Institute of Public Health")
}
