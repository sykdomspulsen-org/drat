# fhimaps 2021.8.5

* Included Kartverket as copyright holder

# fhimaps 1.0.0

* Moving map files from fhidata to fhimaps
* Publishing to CRAN

