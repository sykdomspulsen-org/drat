.onAttach <- function(libname, pkgname) {
  packageStartupMessage("PACKAGE: FHI")
  packageStartupMessage("Version 2020.08.19 at 10:09")
  packageStartupMessage("Developed by Richard White, B Valcarcel, Gunnar R\u00F8")
  packageStartupMessage("Department of Infectious Disease Epidemiology and Modelling")
  packageStartupMessage("Norwegian Institute of Public Health")
}
