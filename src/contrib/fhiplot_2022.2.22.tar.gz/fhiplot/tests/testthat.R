library(testthat)
library(fhiplot)

test_check("fhiplot")
