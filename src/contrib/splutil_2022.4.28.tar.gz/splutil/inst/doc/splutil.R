## ----setup, include = FALSE---------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## -----------------------------------------------------------------------------
splutil::split_equal(c(1:11), size = 3)

## -----------------------------------------------------------------------------
splutil::is_fully_named_list(list(1))
splutil::is_fully_named_list(list("a"=1))

splutil::all_list_elements_null_or_df(list(data.frame()))
splutil::all_list_elements_null_or_df(list(1, NULL))

splutil::all_list_elements_null_or_list(list(1, NULL))
splutil::all_list_elements_null_or_list(list(list(), NULL))

splutil::all_list_elements_null_or_fully_named_list(list(list(), NULL))
splutil::all_list_elements_null_or_fully_named_list(list(list("a" = 1), NULL))

