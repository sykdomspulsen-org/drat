utils::globalVariables(c("%>%", ".", ":=", "isoyear", "isoyearweek", 
                         "n", "time_description", "world_dates_isoyearweek"))