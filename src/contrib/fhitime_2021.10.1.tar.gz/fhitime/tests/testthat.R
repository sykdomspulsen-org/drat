library(testthat)
library(fhitime)

test_check("fhitime")
