## ---- include = FALSE---------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----setup--------------------------------------------------------------------
library(fhidata)
library(data.table)

## -----------------------------------------------------------------------------
fhidata::norway_locations_names_b2020

## -----------------------------------------------------------------------------
fhidata::norway_locations_hierarchy_all_b2020

## -----------------------------------------------------------------------------
fhidata::norway_locations_redistricting_b2020

## -----------------------------------------------------------------------------
fhidata::norway_population_by_age_b2020
fhidata::norway_population_by_age_sex_b2020

## -----------------------------------------------------------------------------
fhidata::norway_locations_names()

## -----------------------------------------------------------------------------
fhidata::norway_locations_redistricting()

## -----------------------------------------------------------------------------
fhidata::norway_locations_hierarchy(from = 'wardoslo', to = 'municip')
fhidata::norway_locations_hierarchy(from = 'municip', to = 'baregion')
fhidata::norway_locations_hierarchy(from = 'county', to = 'faregion')

## -----------------------------------------------------------------------------
fhidata::norway_population_by_age_cats(cats = list(c(1:10), c(11:20)))[]
fhidata::norway_population_by_age_cats(cats = list("one to ten" = c(1:10), "eleven to twenty" = c(11:20)))
fhidata::norway_population_by_age_cats(cats = list(c(1:10), c(11:20), "21+"=c(21:200)))

## -----------------------------------------------------------------------------
fhidata::norway_population_by_age_sex_cats(cats = list(c(1:10), c(11:20)))

