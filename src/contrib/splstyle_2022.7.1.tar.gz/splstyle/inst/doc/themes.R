## ----setup, include = FALSE---------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## -----------------------------------------------------------------------------
library(ggplot2)
library(splstyle)

## -----------------------------------------------------------------------------
q <- ggplot(diamonds[1:200,], aes(carat, depth, color = cut))
q <- q + geom_point(size = 4)
q <- q + splstyle::scale_color_fhi(palette = "primary")
q <- q + labs(title="Theme: 'theme_fhi_basic'")
q <- q + splstyle::theme_fhi_basic()
q

## -----------------------------------------------------------------------------
q <- ggplot(diamonds[1:200,], aes(carat, depth, color = cut))
q <- q + geom_point(size = 4)
q <- q + splstyle::scale_color_fhi(palette = "primary")
q <- q + labs(title="Theme: 'theme_fhi_lines'")
q <- q + splstyle::theme_fhi_lines()
q

## -----------------------------------------------------------------------------
q <- ggplot(diamonds[1:200,], aes(carat, depth, color = cut))
q <- q + geom_point(size = 4)
q <- q + splstyle::scale_color_fhi(palette = "primary")
q <- q + labs(title="Theme: 'theme_fhi_lines_horizontal'")
q <- q + splstyle::theme_fhi_lines_horizontal()
q

## -----------------------------------------------------------------------------
q <- ggplot(diamonds, aes(x=color, fill = cut))
q <- q + geom_bar()
q <- q + splstyle::scale_fill_fhi(palette = "primary")
q <- q + labs(title="Theme: 'theme_fhi_basic'")
q <- q + splstyle::theme_fhi_basic()
q

## -----------------------------------------------------------------------------
q <- ggplot(diamonds, aes(x=color, fill = cut))
q <- q + geom_bar()
q <- q + splstyle::scale_fill_fhi(palette = "primary")
q <- q + labs(title="Theme: 'theme_fhi_lines'")
q <- q + splstyle::theme_fhi_lines()
q

## -----------------------------------------------------------------------------
q <- ggplot(diamonds, aes(x=color, fill = cut))
q <- q + geom_bar()
q <- q + splstyle::scale_fill_fhi(palette = "primary")
q <- q + labs(title="Theme: 'theme_fhi_lines_horizontal'")
q <- q + splstyle::theme_fhi_lines_horizontal()
q

