## ----setup, include = FALSE---------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## -----------------------------------------------------------------------------
library(ggplot2)
library(data.table)
library(splstyle)

## -----------------------------------------------------------------------------
set.seed(4)
dates <- sample(seq.Date(as.Date("2018-01-01"), 
                         as.Date("2018-02-08"), 1),
                20000, 
                replace = T)
d <- expand.grid(
  location_code=unique(fhidata::norway_locations_b2020$county_code),
  date = dates
)
# Convert to data.table
setDT(d)

# print
print(d)

## -----------------------------------------------------------------------------
# Convert to data.table
setDT(d)

# aggregate
d <- d[,
  .(
    N = .N
  ),
  keyby = .(
    location_code,
    date
  )
]
# aggregated daily dataset that does not contain days with 0 cases
print(d)

# create skeleton
skeleton <- data.table(expand.grid(
  location_code = unique(fhidata::norway_locations_b2020$county_code),
  date = seq.Date(min(d$date), max(d$date), 1)
))

# merge the two datasets together
d <- merge(d, skeleton, by=c("location_code", "date"), all=T)

# Fill in 'missing' Ns with 0
d[is.na(N), N := 0]

# Now you have a clean aggregated daily dataset that contains days with 0 cases!
print(d)

## -----------------------------------------------------------------------------
# create 3 new variables:
d[, isoyearweek := fhi::isoyearweek(date)]

# aggregate down to weekly level
w <- d[,
  .(
    N = sum(N)
  ),
  keyby = .(
    location_code,
    isoyearweek
  )
]
print(w)

## -----------------------------------------------------------------------------
q <- ggplot(d[location_code=="county03"], aes(x = date, y = N))
q <- q + geom_col(fill = splstyle::base_color, width = 0.8)
q <- q + scale_x_date("Date")
q <- q + scale_y_continuous("Number of reported cases",
  breaks = splstyle::pretty_breaks(5),
  expand = expansion(mult = c(0, 0.1))
)
q <- q + labs(title = "Epicurve from 2018-01-01 to 2018-02-20")
q <- q + labs(caption = fhi_caption())
q <- q + splstyle::theme_fhi_lines_horizontal()
q

## -----------------------------------------------------------------------------
q <- ggplot(w[location_code=="county03"], aes(x = isoyearweek, y = N))
q <- q + geom_col(fill = splstyle::base_color, width = 0.8)
q <- q + scale_x_discrete("Isoweek")
q <- q + scale_y_continuous("Number of reported cases",
  breaks = splstyle::pretty_breaks(5),
  expand = expansion(mult = c(0, 0.1))
)
q <- q + labs(title = "Epicurve from 2018-01-01 to 2018-02-20")
q <- q + labs(caption = fhi_caption())
q <- q + splstyle::theme_fhi_lines_horizontal()
q

## -----------------------------------------------------------------------------
q <- ggplot(w, aes(x = isoyearweek, y = N))
q <- q + geom_col(fill = splstyle::base_color, width = 0.8)
q <- q + scale_x_discrete("Isoweek")
q <- q + scale_y_continuous("Number of reported cases",
  breaks = splstyle::pretty_breaks(5),
  expand = expansion(mult = c(0, 0.1))
)
q <- q + labs(title = "Epicurve from 2018-01-01 to 2018-02-20")
q <- q + labs(caption = fhi_caption())
q <- q + splstyle::theme_fhi_lines_horizontal()
q <- q + splstyle::set_x_axis_vertical()
q

## ----fig.height=10, fig.width=8-----------------------------------------------
q <- ggplot(d, aes(x = date, y = N))
q <- q + geom_col(fill = splstyle::base_color, width = 0.8)
q <- q + lemon::facet_rep_wrap(~location_code, repeat.tick.labels = "y")
q <- q + splstyle::scale_fill_fhi("Location",palette="primary")
q <- q + scale_x_date("Date")
q <- q + scale_y_continuous("Number of reported cases",
  breaks = splstyle::pretty_breaks(5),
  expand = expansion(mult = c(0, 0.1))
)
q <- q + labs(title = "Epicurve from 2018-01-01 to 2018-02-20")
q <- q + labs(caption = fhi_caption())
q <- q + splstyle::theme_fhi_lines_horizontal()
q <- q + splstyle::set_x_axis_vertical()
q

## ----fig.height=10, fig.width=8-----------------------------------------------
q <- ggplot(d, aes(x = isoyearweek, y = N))
q <- q + geom_col(fill = splstyle::base_color, width = 0.8)
q <- q + lemon::facet_rep_wrap(~location_code, repeat.tick.labels = "y", ncol=4)
q <- q + scale_fill_fhi("Location",palette="primary")
q <- q + scale_x_discrete("Isoweek")
q <- q + scale_y_continuous("Number of reported cases",
  breaks = splstyle::pretty_breaks(5),
  expand = expansion(mult = c(0, 0.1))
)
q <- q + labs(title = "Epicurve from 2018-01-01 to 2018-02-20")
q <- q + labs(caption = fhi_caption())
q <- q + theme_fhi_lines_horizontal()
q <- q + splstyle::set_x_axis_vertical()
q

## -----------------------------------------------------------------------------
q <- ggplot(w[location_code %in% c(
  "county03",
  "county11",
  "county15",
  "county30",
  "county34")], 
  aes(x = isoyearweek, y = N, fill = location_code))
q <- q + geom_col(width = 0.8)
q <- q + splstyle::scale_fill_fhi("Location",palette="primary")
q <- q + scale_x_discrete("Isoweek")
q <- q + scale_y_continuous("Number of reported cases",
  breaks = splstyle::pretty_breaks(5),
  expand = expansion(mult = c(0, 0.1))
)
q <- q + labs(title = "Epicurve from 2018-01-01 to 2018-02-20")
q <- q + labs(caption = fhi_caption())
q <- q + splstyle::theme_fhi_lines_horizontal()
q <- q + splstyle::set_x_axis_vertical()
q

## -----------------------------------------------------------------------------
pd <- w[location_code %in% "county03"]
pd[, cum_n := cumsum(N)]

pd[, value_left := N]
pd[, value_right := cum_n]

max_left <- max(pd$value_left)
max_right <- max(pd$value_right)

# increase the space in the y-axis
max_left <- max(c(max_left, 5))
max_right <- max(c(max_right, 5))

pd[, scaled_value_right := value_right / max_right * max_left]

q <- ggplot(pd, aes(x = isoyearweek))
q <- q + geom_col(
  mapping = aes(
    y = value_left,
    fill = "The fill variable",
  ),
  width = 0.8
  )
q <- q + geom_line(
  mapping = aes(
    y = scaled_value_right,
    group = 1,
    color = "The color variable"
  ),
  lwd = 2
  )
q <- q + scale_x_discrete("Isoweek")
q <- q + scale_y_continuous("Number of reported cases",
  breaks = splstyle::pretty_breaks(5),
  expand = expansion(mult = c(0, 0.1)),
  sec.axis = sec_axis(
    name = "Cumulative number of reported cases\n",
    ~ . * max_right / max_left,
    breaks = splstyle::pretty_breaks(5),
    labels = splstyle::format_nor
  )
)
q <- q + splstyle::scale_fill_fhi("Fill", palette = "primary")
q <- q + splstyle::scale_color_fhi("Color", palette = "posneg")
q <- q + labs(title = "Epicurve from 2018-01-01 to 2018-02-20")
q <- q + labs(caption = fhi_caption())
q <- q + splstyle::theme_fhi_lines_horizontal()
q <- q + splstyle::set_x_axis_vertical()
q

