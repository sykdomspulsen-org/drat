library(testthat)
library(splstyle)

test_check("splstyle")
