## ----setup, include = FALSE---------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## -----------------------------------------------------------------------------
library(ggplot2)
library(data.table)
library(magrittr)

## -----------------------------------------------------------------------------
d_hosp <- spltidy::norway_covid19_icu_and_hospitalization
# check the column names
colnames(d_hosp)  

d_hosp

## -----------------------------------------------------------------------------
d_hosp_weekly <- d_hosp[granularity_time=="isoweek"]


res <- splalert::short_term_trend(
  d_hosp_weekly, 
  numerator = "hospitalization_with_covid19_as_primary_cause_n",
  trend_isoweeks = 6,
  remove_last_isoweeks = 1
)

# create the trend label
res[, hospitalization_with_covid19_as_primary_cause_trend0_42_status := factor(
  hospitalization_with_covid19_as_primary_cause_trend0_42_status,
  levels = c("training","forecast","decreasing", "null", "increasing"),
  labels = c("Training","Forecast","Decreasing", "Null", "Increasing")
)]

colnames(res)

## -----------------------------------------------------------------------------
# check some columns 
res[, .(date, 
        hospitalization_with_covid19_as_primary_cause_n, 
        hospitalization_with_covid19_as_primary_cause_forecasted_n,         hospitalization_with_covid19_as_primary_cause_trend0_42_status)]

## -----------------------------------------------------------------------------
q <- ggplot(res, aes(x = isoyearweek, y = hospitalization_with_covid19_as_primary_cause_forecasted_n, group = 1))
q <- q + geom_col(mapping = aes(fill = hospitalization_with_covid19_as_primary_cause_trend0_42_status ))
q <- q + geom_errorbar(
  mapping = aes(
    ymin = hospitalization_with_covid19_as_primary_cause_forecasted_predinterval_q02x5_n,
    ymax = hospitalization_with_covid19_as_primary_cause_forecasted_predinterval_q97x5_n
  )
)
q <- q + scale_y_continuous("Weekly hospitalization with Covid-19 as primary cause", expand = c(0, 0.1))
q <- q + scale_x_discrete("Isoyearweek", breaks = splstyle::every_nth(8))
q <- q + expand_limits(y=0)
q <- q + splstyle::scale_fill_fhi("6 week trend", palette = "contrast")
q <- q + splstyle::theme_fhi_lines_horizontal(legend_position = "bottom")
q <- q + splstyle::set_x_axis_vertical()
q

## -----------------------------------------------------------------------------
d_hosp_daily <- d_hosp[granularity_time=="day"]

res <- splalert::short_term_trend(
  d_hosp_daily, 
  numerator = "hospitalization_with_covid19_as_primary_cause_n",
  trend_days = 28,
  remove_last_days = 7
)
res[, hospitalization_with_covid19_as_primary_cause_trend0_28_status := factor(
  hospitalization_with_covid19_as_primary_cause_trend0_28_status,
  levels = c("training","forecast","decreasing", "null", "increasing"),
  labels = c("Training","Forecast","Decreasing", "Null", "Increasing")
)]


## -----------------------------------------------------------------------------
q <- ggplot(data = res, mapping = aes(x = date, y = hospitalization_with_covid19_as_primary_cause_forecasted_n, fill = hospitalization_with_covid19_as_primary_cause_trend0_28_status))
q <- q + geom_col(alpha = 0) # necessary to get legend to be in right order
q <- q + geom_col(
  data = res[hospitalization_with_covid19_as_primary_cause_trend0_28_status!="Forecast"]
  )
q <- q + geom_ribbon(
  data = res[hospitalization_with_covid19_as_primary_cause_trend0_28_status=="Forecast"], 
  mapping = aes(
    ymin = hospitalization_with_covid19_as_primary_cause_forecasted_predinterval_q02x5_n,
    ymax = hospitalization_with_covid19_as_primary_cause_forecasted_predinterval_q97x5_n
  ),
  alpha = 0.75
)
q <- q + scale_y_continuous("Daily hospitalization with Covid-19 as primary cause", expand = c(0, 0.1))
q <- q + scale_x_date("Date", date_breaks = "28 days", date_labels = "%y-%m-%d")
# q <- q + scale_x_discrete(breaks = splstyle::every_nth(8))
q <- q + expand_limits(y=0)

q <- q + splstyle::scale_fill_fhi("28 days trend", palette = "contrast")
q <- q + splstyle::theme_fhi_lines_horizontal(legend_position = "bottom")
q <- q + splstyle::set_x_axis_vertical()
q

## -----------------------------------------------------------------------------
q <- ggplot(res, aes(x = date, y = hospitalization_with_covid19_as_primary_cause_doublingdays0_28))
q <- q + geom_rect(aes(xmin = date-1, xmax=date, ymin = 1, ymax = Inf, fill = hospitalization_with_covid19_as_primary_cause_trend0_28_status), alpha = 0.5)
q <- q + geom_line(lwd = 1)
q <- q + scale_y_continuous(trans = "log10", expand = c(0, 0.1))
q <- q + splstyle::scale_fill_fhi(palette = "contrast")
q <- q + splstyle::theme_fhi_lines_horizontal(legend_position = "bottom")
q


