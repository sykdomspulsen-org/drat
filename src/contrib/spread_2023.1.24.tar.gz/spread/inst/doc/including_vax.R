## ---- include = FALSE---------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## -----------------------------------------------------------------------------
library(data.table)
print(spread::nor_seiiar_noinfected_2017_b2020)

## -----------------------------------------------------------------------------
vax_measles <- spread::nor_childhood_vax_b2020[
  calyear==2016 & 
  vaccine=="measles"
  ]

print(vax_measles)

## -----------------------------------------------------------------------------
nor_seiiar_measles_noinfected_2017 <- spread::convert_blank_seiiar_with_vax(
  seiiar = spread::nor_seiiar_noinfected_2017_b2020, 
  vax = vax_measles
  )

## -----------------------------------------------------------------------------
print(nor_seiiar_measles_noinfected_2017)

## -----------------------------------------------------------------------------
nor_seiiar_measles_oslo_2017 <- copy(nor_seiiar_measles_noinfected_2017)
nor_seiiar_measles_oslo_2017[location_code == "municip_nor0301", I := 10]
nor_seiiar_measles_oslo_2017[location_code == "municip_nor0301", S := S - I]

print(nor_seiiar_measles_oslo_2017[location_code=="municip_nor0301"])  

