## ---- include = FALSE---------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----setup--------------------------------------------------------------------
library(attrib)
library(ggplot2)


## ---- warning=FALSE-----------------------------------------------------------
mortality_data_raw <- attrib::data_fake_nowcasting_county_raw
head(mortality_data_raw)
tail(mortality_data_raw)

## ---- warning=FALSE-----------------------------------------------------------
aggregation_date <- as.Date("2020-01-01")
n_week <- 6
unique_locations <- unique(fhidata::norway_locations_b2020$county_code)
pop_data<- fhidata::norway_population_by_age_cats(cats = list(c(1:120)))[location_code %in% unique_locations]
mortality_data_aggregated <-  attrib::nowcast_aggregate(mortality_data_raw,
                                               aggregation_date = aggregation_date, 
                                               n_week = n_week, pop_data = pop_data )

## ---- warning=FALSE-----------------------------------------------------------
tail(mortality_data_aggregated[location_code == "county03"])

## ----fig.height=4, fig.width=6, warning = FALSE-------------------------------
q <- ggplot(data = mortality_data_aggregated[location_code == "county03"], aes(x = cut_doe, y = p0_2))
q <- q + geom_point() 
q <- q + scale_y_continuous("Percentage of deaths registered\n within 2 weeks", limits = c(0,1))
q <- q + theme(axis.title.x=element_blank(), axis.text.x = element_text(angle=90))
q

## ----fig.height=4, fig.width=6, warning = FALSE-------------------------------
q <- ggplot(data = mortality_data_aggregated[location_code == "county03"], aes(x = cut_doe, y = p0_3))
q <- q + geom_point()
q <- q + scale_y_continuous("Percentage of deaths registered\n  within 3 weeks", limits = c(0.5,1))
q <- q + theme(axis.title.x=element_blank(), axis.text.x = element_text(angle=90))
q

## ----fig.height=4, fig.width=6, warning = FALSE-------------------------------
q <- ggplot(data = mortality_data_aggregated[location_code == "county03"], aes(x = cut_doe, y = p0_4))
q <- q + geom_point()
q <- q + scale_y_continuous("Percentage of deaths registered\n  within 4 weeks", limits = c(0.8,1))
q <- q + theme(axis.title.x=element_blank(), axis.text.x = element_text(angle=90))
q

## ---- warning=FALSE-----------------------------------------------------------
data_aggregated <- mortality_data_aggregated
n_week_training <- 50
n_week_adjusting <- 4
date_0 <- aggregation_date
nowcast_correction_fn<- nowcast_correction_fn_negbin_mm
nowcast_correction_sim_fn = nowcast_correction_sim_neg_bin
offset = "log(pop)"
nowcast_object_negbin <-  attrib::nowcast(data_aggregated,
  offset,
  n_week_adjusting,
  n_week_training,
  date_0,
  nowcast_correction_fn = nowcast_correction_fn_negbin_mm,
  nowcast_correction_sim_fn = nowcast_correction_sim_neg_bin)

## ---- warning=FALSE-----------------------------------------------------------
tail(nowcast_object_negbin$data[location_code == "county03"])

## ---- warning=FALSE-----------------------------------------------------------
head(nowcast_object_negbin$data_sim)

## ---- warning=FALSE-----------------------------------------------------------
nowcast_eval_object_negbin <-  attrib::nowcast_eval(nowcast_object_negbin, n_week_adjusting)

## ----fig.height=4, fig.width=6, warning=FALSE---------------------------------
nowcast_eval_object_negbin[[2]]$std_residualplot

## ---- warning=FALSE-----------------------------------------------------------
model_data_negbin <- data.table::data.table(
  ncor = 0:(n_week_adjusting-1)
)

for (i in 0:(n_week_adjusting-1)){
  model_data_negbin[i+1, abs_error := nowcast_eval_object_negbin[[i+1]]$abs_error]
  model_data_negbin[i+1, R_squared := nowcast_eval_object_negbin[[i+1]]$R_squared]
  model_data_negbin[i+1, MSE := nowcast_eval_object_negbin[[i+1]]$MSE]
  model_data_negbin[i+1, RMSE := nowcast_eval_object_negbin[[i+1]]$RMSE]
}

model_data_negbin
model_data_negbin


## ---- warning=FALSE-----------------------------------------------------------
n_week_adjusting <- 5
n_week_training <- 52
offset <- "log(pop)"
date_0 <- aggregation_date
nowcast_object_glm <-  attrib::nowcast(mortality_data_aggregated[location_code == "county03"],
  offset,
  n_week_adjusting,
  n_week_training,
  date_0,
  nowcast_correction_fn = nowcast_correction_fn_quasipoisson,
  nowcast_correction_sim_fn = nowcast_correction_sim_quasipoisson)

## ---- warning=FALSE-----------------------------------------------------------
tail(nowcast_object_glm$data)

## ---- warning=FALSE-----------------------------------------------------------
head(nowcast_object_glm$data_sim)

## ---- warning=FALSE-----------------------------------------------------------
nowcast_eval_object_glm <-  attrib::nowcast_eval(nowcast_object_glm, n_week_adjusting)

## ----fig.height=4, fig.width=6, warning=FALSE---------------------------------
nowcast_eval_object_glm[[2]]$std_residualplot

## ---- warning=FALSE-----------------------------------------------------------
model_data_glm <- data.table::data.table(
  ncor = 0:(n_week_adjusting-1)
)

for (i in 0:(n_week_adjusting-1)){
  model_data_glm[i+1, abs_error := nowcast_eval_object_glm[[i+1]]$abs_error]
  model_data_glm[i+1, R_squared := nowcast_eval_object_glm[[i+1]]$R_squared]
  model_data_glm[i+1, MSE := nowcast_eval_object_glm[[i+1]]$MSE]
  model_data_glm[i+1, RMSE := nowcast_eval_object_glm[[i+1]]$RMSE]
}

model_data_glm
model_data_glm

## ---- warning=FALSE-----------------------------------------------------------

data_train <- mortality_data_aggregated[cut_doe< "2019-06-30"]
data_predict <- mortality_data_aggregated


n_sim <- 1000

response <- "n_death"
fixef <- "1 + sin(2 * pi * (week) / 53) + cos(2 * pi * (week ) / 53) + year"
ranef <- "(1|location_code)"
offset <- "log(pop)"


base_line <-  attrib::baseline_est(data_train, 
                                   data_predict, 
                                   fixef = fixef, 
                                   ranef = ranef, 
                                   response = response, 
                                   offset = offset)

## ---- warning=FALSE-----------------------------------------------------------
nowcast_data_negbin <- data.table::as.data.table(nowcast_object_negbin$data)
nowcast_sim_negbin <- data.table::as.data.table(nowcast_object_negbin$data_sim)

## ---- warning=FALSE-----------------------------------------------------------
# Quantile functions
q025 <- function(x){
  return(quantile(x, 0.025))
}
q975 <- function(x){
  return(quantile(x, 0.975))
}

## ---- warning=FALSE-----------------------------------------------------------
col_names <- colnames(nowcast_sim_negbin)
data.table::setkeyv(nowcast_sim_negbin,
                    col_names[!col_names %in% c("sim_value", "sim_id")])

aggregated_nowcast_sim_negbin<- nowcast_sim_negbin[,
                                   unlist(recursive = FALSE,
                                          lapply(.(median = median, q025 = q025, q975 = q975),
                                                                    function(f) lapply(.SD, f)
                                   )),
                                   by = eval(data.table::key(nowcast_sim_negbin)),
                                   .SDcols = c("sim_value")]
head(aggregated_nowcast_sim_negbin)


## ---- warning=FALSE-----------------------------------------------------------
#nowcast_data[, q025.sim_value := ncor]
nowcast_data_negbin[aggregated_nowcast_sim_negbin, 
                    on = .(cut_doe,location_code), 
                    q025.sim_value := q025.sim_value]

#nowcast_data[, q975.sim_value := ncor]
nowcast_data_negbin[aggregated_nowcast_sim_negbin, 
                    on = .(cut_doe,location_code), 
                    q975.sim_value := q975.sim_value]


## ----fig.height=4, fig.width=6, warning=FALSE---------------------------------
q <- ggplot(base_line$aggregated[year == "2019" & location_code == "county03"],
            aes(x = week,
                y = median.sim_value))
q <- q + geom_ribbon(data = base_line$aggregated[year== 2019 & location_code == "county03"],
                     aes(x = week, ymin=q025.sim_value,
                         ymax=q975.sim_value,
                         colour = "Baseline estimate",
                         fill ="Baseline estimate"),
                     alpha=0.5)
q <- q + geom_line(data = nowcast_data_negbin[year == "2019"& location_code == "county03"],
                   aes(x = week, y = ncor,  colour = "Number of deaths corrected" ))
q <- q + geom_line(data = nowcast_data_negbin[location_code == "county03" & cut_doe> (date_0- 5*7)],
                   aes(x = week, y = q025.sim_value ,colour = "Credible intervall for n corrected" ))
q <- q + geom_line(data = nowcast_data_negbin[location_code == "county03" & cut_doe> (date_0- 5*7)],
                   aes(x = week, y = q975.sim_value, colour = "Credible intervall for n corrected" ))
q <- q + scale_y_continuous(name = "Number of deaths")+ theme(legend.position = "bottom", legend.title = element_blank())
q <- q + guides(fill = FALSE, colour=guide_legend(nrow=2,byrow=TRUE))
q

## ---- warning=FALSE-----------------------------------------------------------
nowcast_data_glm <- data.table::as.data.table(nowcast_object_glm$data)
nowcast_sim_glm <- data.table::as.data.table(nowcast_object_glm$data_sim)

## ---- warning=FALSE-----------------------------------------------------------
col_names <- colnames(nowcast_sim_glm)
data.table::setkeyv(nowcast_sim_glm,
                    col_names[!col_names %in% c("sim_value", "sim_id")])

aggregated_nowcast_sim_glm<- nowcast_sim_glm[,
                                   unlist(recursive = FALSE,
                                          lapply(.(median = median, q025 = q025, q975 = q975),
                                                                    function(f) lapply(.SD, f)
                                   )),
                                   by = eval(data.table::key(nowcast_sim_glm)),
                                   .SDcols = c("sim_value")]
head(aggregated_nowcast_sim_glm)


## -----------------------------------------------------------------------------
 
#nowcast_data[, q025.sim_value := ncor]
nowcast_data_glm[aggregated_nowcast_sim_glm, 
                 on = .(cut_doe,location_code), 
                 q025.sim_value := q025.sim_value]
#nowcast_data[, q975.sim_value := ncor]
nowcast_data_glm[aggregated_nowcast_sim_glm,
                 on = .(cut_doe,location_code), 
                 q975.sim_value := q975.sim_value]

## ----fig.height=4, fig.width=6, warning=FALSE---------------------------------
q <- ggplot(base_line$aggregated[year == "2019" & location_code == "county03"],
            aes(x = week,
                y = median.sim_value))
q <- q + geom_ribbon(data = base_line$aggregated[year== 2019 & location_code == "county03"],
                     aes(x = week, ymin=q025.sim_value,
                         ymax=q975.sim_value,
                         colour = "Baseline estimate",
                         fill ="Baseline estimate"),
                     alpha=0.5)
q <- q + geom_line(data = nowcast_data_glm[year == "2019"& location_code == "county03"],
                   aes(x = week, y = ncor,  colour = "Number of deaths corrected" ))
q <- q + geom_line(data = nowcast_data_glm[location_code == "county03" & cut_doe> (date_0- 5*7)],
                   aes(x = week, y = q025.sim_value ,colour = "Credible intervall for n corrected" ))
q <- q + geom_line(data = nowcast_data_glm[location_code == "county03" & cut_doe> (date_0- 5*7)],
                   aes(x = week, y = q975.sim_value, colour = "Credible intervall for n corrected" ))
q <- q + scale_y_continuous(name = "Number of deaths") 
q <- q + theme(legend.position = "bottom", legend.title = element_blank())
q <- q + guides(fill = FALSE, colour=guide_legend(nrow=2,byrow=TRUE))
q

## ----fig.height=4, fig.width=6, warning=FALSE---------------------------------
q <- ggplot(base_line$aggregated[year == "2019" & location_code == "county03"],
            aes(x = week,
                y = median.sim_value))
q <- q + geom_ribbon(data = base_line$aggregated[year== 2019 & location_code == "county03"],
                     aes(x = week, ymin=q025.sim_value,
                         ymax=q975.sim_value,
                         colour = "Baseline estimate",
                         fill ="Baseline estimate"),
                     alpha=0.5)
q <- q + geom_line(data = nowcast_data_negbin[year == "2019"& location_code == "county03"],
                   aes(x = week, y = ncor,  
                       colour = "Number of deaths corrected negbin" ))
q <- q + geom_line(data = nowcast_data_negbin[location_code == "county03" & cut_doe> (date_0- 5*7)],
                   aes(x = week, y = q025.sim_value, 
                       colour = "Credible intervall for n corrected negbin" ))
q <- q + geom_line(data = nowcast_data_negbin[location_code == "county03" & cut_doe> (date_0- 5*7)],
                   aes(x = week, y = q975.sim_value, 
                       colour = "Credible intervall for n corrected negbin" ))
q <- q + geom_line(data = nowcast_data_glm[year == "2019"& location_code == "county03"],
                   aes(x = week, y = ncor, 
                       colour = "Number of deaths corrected quasipoisson" ))
q <- q + geom_line(data = nowcast_data_glm[location_code == "county03" & cut_doe> (date_0- 5*7)],
                   aes(x = week, y = q025.sim_value,
                       colour = "Credible intervall for n corrected quasipoison" ))
q <- q + geom_line(data = nowcast_data_glm[location_code == "county03" & cut_doe> (date_0- 5*7)],
                   aes(x = week, y = q975.sim_value, 
                       colour = "Credible intervall for n corrected quasipoison" ))
q <- q + scale_y_continuous(name = "Number of deaths") 
q <- q + theme(legend.position = "bottom", legend.title = element_blank())
q <- q + guides(fill = FALSE, colour=guide_legend(nrow=3,byrow=TRUE))

q



