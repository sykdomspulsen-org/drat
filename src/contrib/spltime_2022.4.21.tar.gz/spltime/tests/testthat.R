library(testthat)
library(spltime)

test_check("spltime")
