## ----setup, include = FALSE---------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## -----------------------------------------------------------------------------
library(spltime)
library(magrittr)

## -----------------------------------------------------------------------------
seasonweek_to_isoweek_c(10)
seasonweek_to_isoweek_n(10)
isoweek_to_seasonweek_n(1)  # only has n

## -----------------------------------------------------------------------------
seasonweek_to_isoweek_n(1:52)
isoweek_to_seasonweek_n(1:53)  

