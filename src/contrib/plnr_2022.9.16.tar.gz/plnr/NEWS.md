# plnr 2022.6.8

- plan$set_use_foreach public method created

# plnr 2022.6.7

- CRAN submission
- Additional documentation
- Moving some plan public fields into private

# plnr 2022.5.27

- Including new vignette explaining how to add analyses to a plan.

# plnr 2022.4.6

- Inclusion of hash functions in get_data.

# plnr 2021.6.9

- Inclusion of easy_split.

# plnr 2020.5.11

- fn_name can now take package::function_name arguments.

# plnr 2020.5.4

- is_run_directly function created, allowing the user to see if their code is being run directly or from within a function.

# plnr 2020.4.3

- set_opts function created, allowing for force_verbose to be set package wide.

# plnr 2020.2.20

- create_rmarkdown skeleton created.

# plnr 2020.1.28

- parallel_possible variable when initializing new Plan.
