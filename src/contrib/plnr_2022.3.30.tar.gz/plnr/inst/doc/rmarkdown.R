## ---- collapse=FALSE----------------------------------------------------------
library(ggplot2)
library(data.table)

# We begin by defining a new plan
p <- plnr::Plan$new()

# We add sources of data
# We can add data directly
p$add_data(
  name = "deaths",
  direct = data.table(deaths=1:4, year=2001:2004)
)

# We can add data functions that return data
p$add_data(
  name = "ok",
  fn = function() {
    3
  }
)

# We can then add a simple analysis that returns a figure:

# To do this, we first need to create an analysis function
# (takes two arguments -- data and argset)
fn_fig_1 <- function(data, argset){
  plot_data <- data$deaths[year<= argset$year_max]
  
  q <- ggplot(plot_data, aes(x=year, y=deaths))
  q <- q + geom_line()
  q <- q + geom_point(size=3)
  q <- q + labs(title = glue::glue("Deaths from 2001 until {argset$year_max}"))
  q
}

# We can then add the analysis (function + argset) to the plan
p$add_analysis(
  name = "fig_1_2002",
  fn_name = "fn_fig_1",
  year_max = 2002
)

# And another analysis
p$add_analysis(
  name = "fig_1_2003",
  fn_name = "fn_fig_1",
  year_max = 2003
)

# And another analysis
# (don't need to provide a name if you refer to it via index)
p$add_analysis(
  fn_name = "fn_fig_1",
  year_max = 2004
)

# How many analyses have we created?
p$len()

# When debugging and developing code, we have a number of
# convenience functions that let us directly access the
# data and argsets.

# We can directly access the data:
p$get_data()

# We can access the argset by index (i.e. first argset):
p$get_argset(1)

# We can also access the argset by name:
p$get_argset("fig_1_2002")

# We can acess the analysis (function + argset) by both index and name:
p$get_analysis(1)

# We recommend writing commented-out code for the first two
# lines of the analysis function that directly extracts
# the needed data and argset for one of your analyses.
# This allows for simple debugging and code development
# (the programmer would manually run the first two lines
# of code and then run line-by-line inside the function)
fn_analysis <- function(data, argset){
  # data <- p$get_data()
  # argset <- p$get_argset("fig_1_2002)
  
  # function continues here
}

# We can run the analysis for each argset (by index and name):
p$run_one("fig_1_2002")
p$run_one("fig_1_2003")
p$run_one(3)

## ---- collapse=FALSE----------------------------------------------------------
library(ggplot2)
library(data.table)

# We begin by defining a new plan and adding data
p <- plnr::Plan$new()
p$add_data(direct = data.table(deaths=1:4, year=2001:2004), name = "deaths")

# We can then add the analysis with `fn_name`
p$add_analysis(
  name = "fig_1_2002",
  fn_name = "fn_fig_1",
  year_max = 2002
)

# Or we can add the analysis with `fn_name`
p$add_analysis(
  name = "fig_1_2003",
  fn = fn_fig_1,
  year_max = 2003
)

p$run_one("fig_1_2002")
p$run_one("fig_1_2003")

