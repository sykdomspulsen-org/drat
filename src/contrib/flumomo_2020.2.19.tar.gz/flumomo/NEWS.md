# fhidata 2019.8.27

- Including national population data from 1846 (instead of 2006)

# fhidata 2019.6.24

- Including childhood vaccination data.

# fhidata 2019.5.19

- Switching map files from UTM to lat/long coordinates.

# fhidata 2019.4.2

- Submission to CRAN.
