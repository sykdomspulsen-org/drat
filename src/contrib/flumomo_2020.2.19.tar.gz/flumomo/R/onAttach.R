.onAttach <- function(libname, pkgname) {
  packageStartupMessage("PACKAGE: attrib")
  packageStartupMessage("Version: 2020.02.19 at 13:33")
  packageStartupMessage("Developed by Richard White, Norwegian Institute of Public Health")
}
