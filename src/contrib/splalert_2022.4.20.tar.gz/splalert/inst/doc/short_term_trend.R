## ----setup, include = FALSE---------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## -----------------------------------------------------------------------------
library(ggplot2)
library(data.table)
library(magrittr)

## -----------------------------------------------------------------------------
d <- spltidy::splfmt_rts_data_v1(data.table(
    location_code = "norge",
    date = do.call(c, spltime::dates_by_isoyearweek[isoyear==2020]$days),
    age = "total",
    sex = "total",
    border = 2020
))
set.seed(4)
d[, cases_n := rpois(.N, lambda = seasonweek*4)]

res <- splalert::short_term_trend(d, outcome = "cases_n", trend_days = 28, remove_last_days = 7)
res

q <- ggplot(res, aes(x = date, y = cases_n))
q <- q + geom_rect(aes(xmin = date-1, xmax=date, ymin = -Inf, ymax = Inf, fill = cases_trend0_28_n_status), alpha = 0.5)
q <- q + geom_line(lwd = 1)
q <- q + scale_y_continuous(expand = c(0, 0.1))
q <- q + splstyle::scale_fill_fhi(palette = "contrast")
q <- q + splstyle::theme_fhi_lines_horizontal()
q

q <- ggplot(res, aes(x = date, y = cases_doublingdays0_28_n))
q <- q + geom_rect(aes(xmin = date-1, xmax=date, ymin = 1, ymax = Inf, fill = cases_trend0_28_n_status), alpha = 0.5)
q <- q + geom_line(lwd = 1)
q <- q + scale_y_continuous(trans = "log10", expand = c(0, 0.1))
q <- q + splstyle::scale_fill_fhi(palette = "contrast")
q <- q + splstyle::theme_fhi_lines_horizontal()
q

