library(testthat)
library(splmaps)

test_check("splmaps")
