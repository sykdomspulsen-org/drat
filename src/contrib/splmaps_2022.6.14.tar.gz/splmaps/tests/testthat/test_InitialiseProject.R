context("splmaps")

test_that("Testing", {
  testthat::expect_equal(1, 1)
})
