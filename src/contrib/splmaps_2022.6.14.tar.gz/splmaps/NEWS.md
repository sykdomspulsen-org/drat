# splmaps 2022.6.8

- Refactored the .rd files.

# splmaps 2022.6.6

- Migrated content from fhimaps to splmaps

- Updated documentation

# splmaps 2020.2.17

- Package is created (previously as fhimaps)
