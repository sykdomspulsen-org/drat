# normomo 2018.10.25

## Migration

Migrating from [raubreywhite/dashboards_normomo](https://www.github.com/raubreywhite/dashboards_normomo/) to [folkehelseinstituttet/dashboards_normomo](https://www.github.com/folkehelseinstituttet/dashboards_normomo/)