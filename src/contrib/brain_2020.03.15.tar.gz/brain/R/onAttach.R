.onAttach <- function(libname, pkgname) {
  packageStartupMessage("PACKAGE: brain")
  packageStartupMessage("Version 2020.03.15 at 16:21")
  packageStartupMessage("Developed by Richard White, Norwegian Institute of Public Health")
}
