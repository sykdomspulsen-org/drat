#' actions
#' @export
actions <- new.env()
