library(testthat)
library(brain)

test_check("brain")
